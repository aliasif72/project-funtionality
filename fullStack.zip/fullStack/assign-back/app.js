const express=require('express');
const app=express();
const cors=require('cors');
const mongoose=require('mongoose');
require('dotenv').config();
const port=process.env.PORT;
const mongodb=process.env.MONGODB;
const multer=require('multer');

const userRoute=require('./route/user');
const authFn=require('./auth/auth');

app.use(cors());


const storage= multer.diskStorage({
    destination: (req,file,cb)=>{
     cb(null,"./uploads/");
    },
    filename:(req,file,cb)=>{
     cb(null,  file.originalname.toLowerCase().split(' ').join('-'));
    }
  })
     const upload=multer({storage:storage ,fileFilter: (req, file, cb) => {
        if (file.mimetype == "image/png" || file.mimetype == "image/jpg" || file.mimetype == "image/jpeg") {
            cb(null, true);
        } else {
            cb(null, false);
            return cb(new Error('Only .png, .jpg and .jpeg format allowed!'));
        }
    }
    });

app.use(express.json());
app.use(express.static('uploads'));

app.use('/user',upload.single("image"),(req,res,next)=>{
        next();
})
app.use('/user/loggedin',authFn.auth)
app.use('/user',userRoute);


mongoose.connect(mongodb)
.then(()=>{
    app.listen(port,()=>console.log(`Server started on PORT:${port}`))
    console.log("MONGO CONNECTED");
})
.catch(err=>console.log(err));
