const bcrypt=require('bcryptjs');
const User=require("../model/user");
const jwt = require('jsonwebtoken');

///SIGNUP
    exports.signUp = async(req,res) =>{
    const{name,email,password,phone,type}=req.body;
    let isAdmin=false;
    if(type==="Admin")
    {
        console.log(type);
        isAdmin=true;
    }
    let image='';
    if(req.file)
    {
        const url = req.protocol + '://' + req.get('host');
        image = url+'/'+ req.file.originalname;
        }
    const saltRounds=10;
    bcrypt.hash(password,saltRounds,(err,hash)=>{
            if(hash){
             User.create({
             name,
             email,
             phone,
             password:hash,
             image:image,
             isAdmin
        })
        .then((user)=>{
            res.status(201).json({title:"Congratulations",message:"Sign Up successful!"})
        })
          .catch((err)=>{
            console.log(err);
             res.status(401).json({err:err, title:"Error",message:"Email/Phone is already registered"})
            })}
    
    })}


///TOKEN GENERATE
function generateToken(id,name,email,isAdmin)
{
   return jwt.sign({id,name,email,isAdmin}, "asifali");
}


///LOGIN
exports.login = async(req,res) =>{
     const{inputEmail,inputPassword}=req.body;
     let users=[];
    try{
    const user=await User.find({email:inputEmail});
    if(user[0].isAdmin){
        users=await User.find();
        }
    if(user.length===0){
        return res.status(401).json({title:"Error", message:"User Not Found"})
    }
    bcrypt.compare(inputPassword,user[0].password,(err,result)=>{
   if(result){
   return res.status(201).json({title:"Welcome",user:user[0],users:users,name:user[0].name, message:"Login Success", token:generateToken(
             user[0]._id,
             user[0].name,
             user[0].email,
             user[0].isAdmin
             )
            })}
      res.status(401).json({title:"Error", message:"Password Mismatch"})
    })}
       catch(err)
    {
        console.log(err)
    }
}

//EDIT
exports.edit = async(req,res) =>{
    const{name, id}=req.body;
    let users=[];
    let image=req.body.image;
    try{
        if(req.file)
        {  
        const url = req.protocol + '://' + req.get('host');
        image = url+'/'+ (req.file.originalname );
        }
        const doc = await User.findOne({_id:id})
        doc.name=name;
        doc.image=image;
        const user=await doc.save()
         if(req.user.isAdmin)
         {
            users=await User.find()
         }
         console.log(user)
         console.log(users)
         res.status(201).json({title:"Success",user:user, users:users, isAdmin:true, message:"Update successful!"})
        }
        catch(err)
        {
            console.log(err);
            }}
    


//DELETE
exports.delete = async(req,res) =>{
    const id=req.params.id;
   try{
    const user=await User.deleteOne({_id:id});
      res.status(201).json({title:"Success", message:"Successfully Deleted"})
      }
      catch(err)
   {
       console.log(err)
   }
}

    