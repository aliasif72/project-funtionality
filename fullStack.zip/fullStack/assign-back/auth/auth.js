const User=require('../model/user');
const jwt=require('jsonwebtoken');

exports.auth = async(req,res,next) =>{
try{
const token= req.header("authorization");
const user=jwt.verify(token,"asifali");
await User.findOne({_id:user.id})
.then((result)=>{
    req.user=result;
    next();
})
}
catch(err){
    console.log(err);
}
}