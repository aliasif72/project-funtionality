import Error from "./Error";
import { useContext, useState, React } from "react";
import axios from 'axios';
import Card from "../UI/Card";
import Button from "../UI/Button";
import ArrContext from "./store/ArrContext";
import AuthContext from "./store/AuthContext";

function Edit(props){

    const[data,setData]=useState({
        inputName:props.user.name,
        inputImage:props.user.image
    })
    
const[messg,setMessg]=useState(false);
    
const ctxArr=useContext(ArrContext);
const ctx=useContext(AuthContext);
 
function nameHandler(event){
    setData((prevData)=> {
        return { ...prevData,inputName:event.target.value }
    })
}

function imageHandler(event){
         setData((prevData)=>{
          return { ...prevData,inputImage: event.target.files[0] || data.inputImage}
    })
}
            
function formSubmit(event){
    event.preventDefault();
    if(data.inputName.trim().length===0 && data.inputImage.trim().length===0)
    {
       return setMessg({
            title:'Invalid Input',
            msg:'Please enter a valid details'
        })
         }
         const formData=new FormData();
         formData.append('image',data.inputImage);   
         formData.append('name',data.inputName);
         formData.append('id',props.user._id);   
         const token=JSON.parse(localStorage.getItem('token'));
         axios.put("http://localhost:4000/user/loggedin/edit",formData,{headers:{authorization:token}})
         .then((res)=>{
                setMessg({
                title:res.data.title,
                msg:res.data.message 
            })
            if(ctxArr.userObj.isAdmin)
            {
                localStorage.setItem('user',JSON.stringify(res.data.users))  
                ctxArr.array=[...res.data.users];
            }
            else
            {
                localStorage.setItem('user',JSON.stringify([res.data.user]))
                localStorage.setItem('name',JSON.stringify(res.data.user.name))
                ctxArr.array=[res.data.user];
                }
          
      })
         .catch((err)=>
         {
            setMessg({
                title:err.response.data.title,
                msg:err.response.data.message
            })
            console.log(err)}
            );
        setData({
        inputName:'',
        inputImage:''
     })
}

    function closeHandler(){
        setMessg(false);
        ctx.doneEdit(localStorage.getItem('name'));
        props.onDone();
          }

    return(
       <>
        <Card className="container">
        <form onSubmit={formSubmit}>
        <label> Name </label>
         <input onChange={nameHandler} value={data.inputName} type="text"/>
         <br/><br/>
         <button type="button"><input name="image" onChange={imageHandler} type="file"/>
         <h2>Profile Image</h2></button>
         <Button className="submit" type="submit" text="Save"></Button>
     
         </form>    <br/> <br/>
         <br/> <br/>
        </Card>
         {(messg) && <Error title={messg.title} msg={messg.msg} onClose={closeHandler}/>}
         </>
    )
}

export default Edit;
