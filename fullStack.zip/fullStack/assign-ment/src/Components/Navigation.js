import React, { useContext }  from 'react';
import './Navigation.css';
import AuthContext from './store/AuthContext';

function Navigation () {
  const authCtx= useContext(AuthContext);
  return (
    <nav className='nav'>
      <ul>      
          <li>
          <p> Welcome {JSON.parse(localStorage.getItem('name')  )} </p>  
          </li>
            <li>
            <button onClick={authCtx.onLogout}>Logout</button>
          </li>
            </ul>
    </nav>
  )
}

export default Navigation;
