import Card from "../UI/Card"
import Button from "../UI/Button";
import { useReducer,useEffect, useContext } from "react";
import Signup from "./Signup";
import Login from "./Login";
import Profile from "./Profile";
import AuthContext from "./store/AuthContext";
import ArrContext from "./store/ArrContext";


function reducerForm(state, action)
{
  if(action)
  {
  return action;
  }
  else
  {
    return "1"
  }
}

function Form(props){

  useEffect(()=>{
    dispatchForm(localStorage.getItem('type'));
  },[])

const[form, dispatchForm] = useReducer(reducerForm, "1");
const ctx=useContext(ArrContext);

      function signinForm(){
         dispatchForm("2");
       }
      
      function signupForm(){
        dispatchForm("3");   
      }

      function signinHandler(name){
        localStorage.setItem('name',name);
        dispatchForm("4")
        localStorage.setItem('type',"4");
      }

      function signOut(){
         localStorage.removeItem('token');
         localStorage.removeItem('user');
         localStorage.removeItem('type');
         localStorage.removeItem('name');
         dispatchForm("1");
         ctx.array=[];
             }

    if(form=== "1") 
    return(
 <Card className="container">
   <h2>Welcome to Registration</h2>
 <Button className="submit" onClose={signinForm} type="submit" text="Sign in"></Button>
 <Button className="submit" onClose={signupForm} type="submit" text="Sign up"></Button>
 <br/> <br/> 
  <br/> <br/>
</Card>
    )
    else if(form === "2")
    {
        return( <Login onSuccess={signinHandler} />)
    }
    else if(form ==='3')
    {
        return (<Signup onSuccess={signinForm} />)
    }
    else
    {
         return (
          <AuthContext.Provider 
          value= {{
           onLogout:signOut,
           doneEdit:signinHandler
           }}>
            <Profile />
            </AuthContext.Provider> )
     }
}

export default Form;