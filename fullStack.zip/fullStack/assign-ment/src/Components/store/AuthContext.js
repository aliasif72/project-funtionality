import React from "react";

const AuthContext= React.createContext({
    array: []
})

export default AuthContext;