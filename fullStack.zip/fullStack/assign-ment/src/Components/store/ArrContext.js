import React from "react";

const ArrContext= React.createContext({
    array:[],
    userObj:{}
})

export default ArrContext;