import Card from "../UI/Card";
import '../UI/Card.css'
import MainHeader from "./MainHeader";
import React from "react";
import ArrContext from "./store/ArrContext";
import { useContext, useState} from "react";
import Button from "../UI/Button";
import axios from 'axios';
import Edit from "./Edit";
import AuthContext from "./store/AuthContext";

function Profile(){
const ctx = useContext(ArrContext);
const authCtx = useContext(AuthContext);
const [edit, setEdit]=useState(false);
const[arr,setArr] = useState(ctx.array)


function editDone(){
  setArr(ctx.array);
  setEdit(false);
  
}

 function onDelete(id){
  const token=JSON.parse(localStorage.getItem('token'));
  axios.delete(`http://localhost:4000/user/loggedin/delete/${id}`,{headers:{authorization:token}})
  if(id===ctx.userObj._id) 
   {return authCtx.onLogout();}
   ctx.array = ctx.array.filter((ele)=> ele._id!==id)
   setArr(ctx.array);
   localStorage.setItem('user',JSON.stringify(ctx.array))
}

function onEdit(ele){
    setEdit({
    ele:ele
 })}

       return (
        <React.Fragment>
       <MainHeader/>
        {(arr.length===0) ? authCtx.onLogout()  : arr.map((ele)=>
        {
         return <Card key={Math.round(Math.random()*100)} className="display">
         <p>Name : {ele.name}</p>
         <p>Email : {ele.email}</p>
         <p>Phone : {ele.phone}</p>
        <img alt="profile" src={ele.image}/>
         <Button className="submit" onClose={()=>onEdit(ele)} type="submit" text="Edit"/>
         <Button className="submit" onClose={()=>onDelete(ele._id)} type="submit" text="Delete"/>
        </Card>
        })}
        {(edit) && <Edit onDone={editDone} user={edit.ele}/>}
       </React.Fragment>
       )
   
}

export default Profile;