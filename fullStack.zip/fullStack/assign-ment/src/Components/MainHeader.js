import React from 'react';
import Navigation from './Navigation';
import './MainHeader.css';

const MainHeader = () => {
  return (
    <header className='main-header'>
      <h1>User Profile Management</h1>
      <Navigation/>
    </header>
      );
};

export default MainHeader;
