import Card from '../UI/Card';
import './Form.css';
import { useState,useContext } from 'react';
import axios from 'axios';
import Button from '../UI/Button';
import Error from './Error';
import React from 'react';
import ArrContext from './store/ArrContext';

function Login(props)
{
  
    const ctx=useContext(ArrContext);
    const[data,setData]=useState({
        inputEmail:'',
        inputPassword:'',
    })
    
    const[messg,setMessg]=useState(false);

    const[logIn,setLogin]=useState(false);
    
    function emailHandler(event){
    setData((prevData)=> {
        return { ...prevData,inputEmail:event.target.value }
    })
    }

    function passwordHandler(event){
        setData((prevData)=> {
            return { ...prevData,inputPassword:event.target.value }
        })
        }
                
    function formSubmit(event){
        event.preventDefault();
        if(data.inputEmail.trim().length===0 || data.inputPassword.trim().length===0 )
        {
           return setMessg({
                title:'Invalid Input',
                msg:'Please enter a valid details'
            })
             }
            axios.post("http://localhost:4000/user/login",data)
             .then((res)=>{
                localStorage.setItem('token',JSON.stringify(res.data.token));
                setMessg({
                    title:res.data.title ,
                    msg:res.data.message 
                })
                setLogin(JSON.stringify(res.data.name));
                if(res.data.user.isAdmin)
                {
                localStorage.setItem('user',JSON.stringify(res.data.users));
                ctx.array=[...res.data.users];
                }
                else
                {
                    localStorage.setItem('user',JSON.stringify([res.data.user]));
                    ctx.array.push(res.data.user);
                }
               ctx.userObj={...res.data.user};
               console.log(ctx.userObj)
                    })
             .catch((err)=>
             {
                setMessg({
                    title: err.response.data.title, 
                    msg:err.response.data.message
                })
                console.log(err)
            })
            setData({
            inputEmail:'',
            inputPassword:'',
         })
    }

    function closeHandler(){
        setMessg(false);
        (logIn) && props.onSuccess(logIn);


    }

return(
    <React.Fragment>
    <Card className="container">
    <form onSubmit={formSubmit}>
     <label> Email </label>
     <input  onChange={emailHandler} value={data.inputEmail} type="email"/>
     <label> Password </label>
     <input onChange={passwordHandler} value={data.inputPassword} type="password" />
     <br/><br/>
     <Button className="submit" type="submit" text="Login"></Button>
     <br/> <br/>
     </form>
     <br/> <br/>
    </Card>
    {(messg) && <Error title={messg.title} msg={messg.msg} onClose={closeHandler} />}
    </React.Fragment>
)
}

export default Login;