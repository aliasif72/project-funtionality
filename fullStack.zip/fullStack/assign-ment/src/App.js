import Form from './Components/Form';
import ArrContext from './Components/store/ArrContext';

function App() {
  let userData=[];
  if(localStorage.getItem('user'))
  {
  userData= [...JSON.parse(localStorage.getItem('user'))]
  }
    return (
    <ArrContext.Provider value={{
      array:[...userData],
      userObj:{}
    }}>
      <Form />
      </ArrContext.Provider>
  )
}

export default App;
