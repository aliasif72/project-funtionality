const TODO=require('../model/info');

exports.addTODO= (req,res,next)=>{
const name=req.body.name;
const description=req.body.description;
const status=req.body.status;
TODO.create({
    name:name,
    description:description,
    status:status,
   })
.then((result)=>res.status(200).json((result)))
.catch(err=>console.log(err));
}

 exports.getTODO= async(req,res,next)  =>{
  try{
   let result= await TODO.findAll({where: { status:'undone'}});
    res.status(200).json(result);
     }
    catch(err)
         {
          console.log(err);
         }
            }

  exports.getDoneTODO= async(req,res,next)  =>{     
     try{
      let result= await TODO.findAll({where: { status:'done'}});
      res.status(200).json(result);
                }
         catch(err)
  {       
     console.log(err);
                     }
                        }
   

   exports.deleteTODO= (req,res,next)=>{
     const idd=req.params.Nid;                                       //  TODO.findByPk(idd)
             TODO.destroy({ where: { Id: idd} })                      //.then(product=> 
             .then((result)=>res.status(200).send('deleted'))        //  {return product.destroy()})
             .catch(err=>console.log(err));                            //.then(result=>
             }                                                             //{console.log("deleted");
                                                  

    exports.addDoneTODO= async(req,res,next)=>{
               const idd=req.body.Id;
               await TODO.findByPk(idd)                    
              .then((result)=>
                      {
                        result.status='done';
                        return result.save();
                      })
                       .then(resp =>res.status(200).json(resp))
                      .catch(err=>console.log(err));                         
                      }               
                    
          